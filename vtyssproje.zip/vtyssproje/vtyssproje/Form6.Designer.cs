﻿namespace vtyssproje
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.dgvEmployeeProjects = new System.Windows.Forms.DataGridView();
            this.lblNotStartedTasks = new System.Windows.Forms.Label();
            this.lblCompletedTasks = new System.Windows.Forms.Label();
            this.lblTotalTasks = new System.Windows.Forms.Label();
            this.lblInProgressTasks = new System.Windows.Forms.Label();
            this.lblEmployeeEmail = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblOnTimeTasks = new System.Windows.Forms.Label();
            this.lblLateTasks = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeProjects)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmployeeProjects
            // 
            this.dgvEmployeeProjects.BackgroundColor = System.Drawing.Color.Lavender;
            this.dgvEmployeeProjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployeeProjects.GridColor = System.Drawing.Color.Silver;
            this.dgvEmployeeProjects.Location = new System.Drawing.Point(74, 29);
            this.dgvEmployeeProjects.Name = "dgvEmployeeProjects";
            this.dgvEmployeeProjects.RowHeadersWidth = 51;
            this.dgvEmployeeProjects.RowTemplate.Height = 24;
            this.dgvEmployeeProjects.Size = new System.Drawing.Size(908, 265);
            this.dgvEmployeeProjects.TabIndex = 0;
            // 
            // lblNotStartedTasks
            // 
            this.lblNotStartedTasks.AutoSize = true;
            this.lblNotStartedTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblNotStartedTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNotStartedTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblNotStartedTasks.Location = new System.Drawing.Point(839, 333);
            this.lblNotStartedTasks.Name = "lblNotStartedTasks";
            this.lblNotStartedTasks.Size = new System.Drawing.Size(0, 20);
            this.lblNotStartedTasks.TabIndex = 3;
            // 
            // lblCompletedTasks
            // 
            this.lblCompletedTasks.AutoSize = true;
            this.lblCompletedTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblCompletedTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCompletedTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblCompletedTasks.Location = new System.Drawing.Point(830, 430);
            this.lblCompletedTasks.Name = "lblCompletedTasks";
            this.lblCompletedTasks.Size = new System.Drawing.Size(0, 20);
            this.lblCompletedTasks.TabIndex = 6;
            // 
            // lblTotalTasks
            // 
            this.lblTotalTasks.AutoSize = true;
            this.lblTotalTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTotalTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblTotalTasks.Location = new System.Drawing.Point(830, 489);
            this.lblTotalTasks.Name = "lblTotalTasks";
            this.lblTotalTasks.Size = new System.Drawing.Size(0, 20);
            this.lblTotalTasks.TabIndex = 5;
            // 
            // lblInProgressTasks
            // 
            this.lblInProgressTasks.AutoSize = true;
            this.lblInProgressTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblInProgressTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblInProgressTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblInProgressTasks.Location = new System.Drawing.Point(829, 377);
            this.lblInProgressTasks.Name = "lblInProgressTasks";
            this.lblInProgressTasks.Size = new System.Drawing.Size(0, 20);
            this.lblInProgressTasks.TabIndex = 4;
            // 
            // lblEmployeeEmail
            // 
            this.lblEmployeeEmail.AutoSize = true;
            this.lblEmployeeEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmployeeEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEmployeeEmail.ForeColor = System.Drawing.Color.Navy;
            this.lblEmployeeEmail.Location = new System.Drawing.Point(379, 333);
            this.lblEmployeeEmail.Name = "lblEmployeeEmail";
            this.lblEmployeeEmail.Size = new System.Drawing.Size(0, 20);
            this.lblEmployeeEmail.TabIndex = 9;
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.BackColor = System.Drawing.Color.Transparent;
            this.lblEmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblEmployeeName.ForeColor = System.Drawing.Color.Navy;
            this.lblEmployeeName.Location = new System.Drawing.Point(379, 384);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(0, 20);
            this.lblEmployeeName.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label3.Location = new System.Drawing.Point(298, 333);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(285, 384);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(12, 500);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "number of tasks not completed on time:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(44, 444);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(310, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "number of tasks completed on time:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label5.Location = new System.Drawing.Point(552, 333);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(247, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "number of tasks not started:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label6.Location = new System.Drawing.Point(682, 489);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Total tasks:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label7.Location = new System.Drawing.Point(552, 430);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(248, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "number of tasks completed :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label8.Location = new System.Drawing.Point(552, 377);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(238, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "number of tasks continius :";
            // 
            // lblOnTimeTasks
            // 
            this.lblOnTimeTasks.AutoSize = true;
            this.lblOnTimeTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblOnTimeTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOnTimeTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblOnTimeTasks.Location = new System.Drawing.Point(380, 448);
            this.lblOnTimeTasks.Name = "lblOnTimeTasks";
            this.lblOnTimeTasks.Size = new System.Drawing.Size(0, 20);
            this.lblOnTimeTasks.TabIndex = 19;
            // 
            // lblLateTasks
            // 
            this.lblLateTasks.AutoSize = true;
            this.lblLateTasks.BackColor = System.Drawing.Color.Transparent;
            this.lblLateTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLateTasks.ForeColor = System.Drawing.Color.Navy;
            this.lblLateTasks.Location = new System.Drawing.Point(380, 500);
            this.lblLateTasks.Name = "lblLateTasks";
            this.lblLateTasks.Size = new System.Drawing.Size(0, 20);
            this.lblLateTasks.TabIndex = 20;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1059, 584);
            this.Controls.Add(this.lblLateTasks);
            this.Controls.Add(this.lblOnTimeTasks);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblEmployeeName);
            this.Controls.Add(this.lblEmployeeEmail);
            this.Controls.Add(this.lblCompletedTasks);
            this.Controls.Add(this.lblTotalTasks);
            this.Controls.Add(this.lblInProgressTasks);
            this.Controls.Add(this.lblNotStartedTasks);
            this.Controls.Add(this.dgvEmployeeProjects);
            this.Name = "Form6";
            this.Text = "Employee Details";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeProjects)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmployeeProjects;
        private System.Windows.Forms.Label lblNotStartedTasks;
        private System.Windows.Forms.Label lblCompletedTasks;
        private System.Windows.Forms.Label lblTotalTasks;
        private System.Windows.Forms.Label lblInProgressTasks;
        private System.Windows.Forms.Label lblEmployeeEmail;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblOnTimeTasks;
        private System.Windows.Forms.Label lblLateTasks;
    }
}